// 💡 Interface pour les liens de navigation

export interface RouterLinkProps {
  href: string;
  path: string;
}
