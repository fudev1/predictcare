
const HearthPage = () => {
  return (
    <div>HearthPage</div>
  )
}

export default HearthPage