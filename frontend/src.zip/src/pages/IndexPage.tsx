
const IndexPage = () => {
  return (
    <div>IndexPage</div>
  )
}

export default IndexPage