import { Box, Typography } from '@mui/material';

const LoginPage = () => {
  return (
    <>
      <Box
        display={'flex'}
        gap={8}
        flexDirection={'column'}
        justifyContent={'center'}
        alignItems={'center'}
        bgcolor={'#f5f5f5'}
        minHeight={'100vh'}
        p={8}
      >
        <div>
          <Typography fontSize={32} fontWeight={700} textAlign={'center'}>
            Hi, Welcome back !
          </Typography>
          <Typography textAlign={'center'} component="p">
            Vous pouvez vous connecter.
          </Typography>
        </div>

        <Box
          component="img"
          src="https://github.com/minimal-ui-kit/material-kit-react/blob/main/public/assets/images/avatars/avatar_1.jpg?raw=true"
          alt="login"
        />
      </Box>
    </>
  );
};

export default LoginPage;
