
const LungPage = () => {
  return (
    <div>LungPage</div>
  )
}

export default LungPage